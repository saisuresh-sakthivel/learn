exports.bar1 = require('./bar1');
exports.bar2 = require('./bar2');
