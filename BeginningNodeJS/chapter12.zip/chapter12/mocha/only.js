describe.only('first', function () {
    it('test 1', function () {
    });
});

describe('second', function () {
    it('test 1', function () {
    });
});