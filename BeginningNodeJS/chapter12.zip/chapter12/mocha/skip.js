describe('first', function () {
    it('test 1', function () {
    });
});

describe.skip('second', function () {
    it('test 1', function () {
    });
});

describe('third', function () {
    it('test 1', function () {
    });
});