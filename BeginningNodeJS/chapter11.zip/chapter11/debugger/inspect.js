for (var index = 0; index < 10; index++) {
    var message = 'Loop ' + index;
    debugger;
    console.log(message);
}