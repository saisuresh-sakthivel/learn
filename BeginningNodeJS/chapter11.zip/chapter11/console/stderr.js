console.log('Good output');
console.error('Error message');