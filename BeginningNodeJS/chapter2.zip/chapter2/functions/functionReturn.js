function foo() { return 123; }
console.log(foo()); // 123

function bar() { }
console.log(bar()); // undefined
