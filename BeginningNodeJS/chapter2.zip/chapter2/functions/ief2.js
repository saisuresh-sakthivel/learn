var foo = 123;
if (true) {
    var foo = 456;
}
console.log(foo); // 456; 
