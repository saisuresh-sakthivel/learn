process.on('exit', function (code) {
    console.log('Exiting with code:', code);
});

process.exit(1);