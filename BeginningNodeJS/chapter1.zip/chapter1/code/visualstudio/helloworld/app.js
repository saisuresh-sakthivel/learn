
console.log('Hello world');
